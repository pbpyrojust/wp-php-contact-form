// just for the demos, avoids form submit
$j.validator.setDefaults({
  debug: true
});
$j( ".aw-contact-form" ).validate({
  rules: {
  	cf_first_name: "required",
    cf_email: "required",
    cf_re_email: {
      equalTo: "#cf_email"
    }
  }
});